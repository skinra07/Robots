﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace DataRobot
{
    enum STOP_TYPE
    {
        NONE = 0,
        MANUAL = 2, 
        EXPIRED = 4
    }

    public partial class Form1 : Form
    {
        private int countDown = 0;
        private System.Timers.Timer timerClock;
       
        private STOP_TYPE running = STOP_TYPE.EXPIRED;  //(Default, not running)

        private const string DEFAULT_TIMER = "00:02:00";

        private DisplayRobot displayRobot = null;

        public Form1()
        {
            InitializeComponent();
            InitializeTimer();

            EnableStopButton(false);
            EnableStartButton(true);

            textBox_Messages.Text = string.Empty;
        }

        private void InitializeTimer()
        {
            timerClock = new System.Timers.Timer();
            timerClock.Interval = 1000;
            timerClock.Elapsed += OnTimerEvent; 
        }

        private void InitializeDisplayRobot()
        {
            running = STOP_TYPE.EXPIRED;
            displayRobot = new DisplayRobot();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            InitializeDisplayRobot();

            ConvertInputToSeconds(txtInputTimer.Text);

            if (countDown > 0)
            {
                timerClock.Start();

                displayRobot.StartRunning();

                running = STOP_TYPE.NONE;  //( running is true)

                CreateMessageDisplayListener();

                EnableStartButton(false);
                EnableStopButton(true);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timerClock.Stop();
            displayRobot.StopRunning();

            EnableStartButton(true);
            EnableStopButton(false);

            if (countDown == 0)
            {
                running = STOP_TYPE.EXPIRED;
                displayRobot.CreateCSVFile();
                MessageBox.Show(" Successfully Finish. CSV Report is Created.");
            }
            else
            {
                running = STOP_TYPE.MANUAL;
                MessageBox.Show("Requested Process is Stopped.");
            }

            displayRobot.Dispose(true);
            UpdateText(DEFAULT_TIMER);
        }

        private void EnableStartButton(bool val)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => this.EnableStartButton(val)));
                return;
            }

            btnStart.Enabled = val;
        }

        private void EnableStopButton(bool val)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => this.EnableStopButton(val)));
                return;
            }

            btnStop.Enabled = val;
        }

        private void OnTimerEvent(object sender, ElapsedEventArgs e)
        {
            if ( countDown > 0 )
            {
                --countDown;
                secondsToTime(countDown);
            }
            else
            {
                btnStop_Click(sender, e);
            }
        }
        private void ConvertInputToSeconds(string timerInput)
        {
            try
            {
                string[] timeArray = new string[3];

                int minutes = 0;
                int hours = 0;
                int seconds = 0;
                
                timeArray = timerInput.Split(':');

                seconds = Convert.ToInt32(timeArray[2]);
                minutes = Convert.ToInt32(timeArray[1]);
                hours = Convert.ToInt32(timeArray[0]);

                countDown = 0;
                countDown += seconds;
                countDown += minutes * 60;
                countDown += (hours * 60) * 60;

                if ( countDown == 0 )
                {
                    MessageBox.Show("Please input duration of time greater than 0");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("ConvertInputToSeconds(): " + e.Message);
            }
        }

        private void UpdateTimer(string text)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => this.UpdateTimer(text)));
                return;
            }

            txtInputTimer.Text = text;
        }

        private void UpdateText(string text)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => this.UpdateTimer(text)));
                return;
            }

            txtInputTimer.Text = text;
        }

        private void secondsToTime(int seconds)
        {
            int minutes = 0;
            int hours = 0;

            while (seconds >= 60)
            {
                minutes += 1;
                seconds -= 60;
            }
            while (minutes >= 60)
            {
                hours += 1;
                minutes -= 60;
            }


            string timerText = string.Format("{0}:{1}:{2}", hours.ToString().PadLeft(2, '0'), minutes.ToString().PadLeft(2, '0'), seconds.ToString().PadLeft(2, '0'));
            UpdateTimer(timerText);
        }

        private void CreateMessageDisplayListener()
        {
            var bw = new BackgroundWorker();

            bw.DoWork += (sender, args) =>
            {
                while ( (running == STOP_TYPE.NONE) )
                {
                    Thread.Sleep(1000);

                    if (textBox_Messages != null)
                            {
                                if (textBox_Messages.InvokeRequired)
                                {
                                    textBox_Messages.Invoke(new Action(() =>
                                    {
                                        textBox_Messages.Text = displayRobot.CreateDisplayData();
                                    }));
                                }
                                else
                                {
                                    textBox_Messages.Text = displayRobot.CreateDisplayData();
                                }
                            
                            }
                }
            };

            bw.RunWorkerAsync();
        }

    }
}
