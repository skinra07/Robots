﻿using System;

namespace DataRobot
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtInputTimer = new System.Windows.Forms.TextBox();
            this.textBox_Messages = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(37, 249);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(154, 249);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // txtInputTimer
            // 
            this.txtInputTimer.Location = new System.Drawing.Point(528, 252);
            this.txtInputTimer.Name = "txtInputTimer";
            this.txtInputTimer.Size = new System.Drawing.Size(90, 20);
            this.txtInputTimer.TabIndex = 2;
            this.txtInputTimer.Text = "00:02:00";
            this.txtInputTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtInputTimer.TextChanged += new System.EventHandler(this.txtInputTimer_TextChanged);
            // 
            // textBox_Messages
            // 
            this.textBox_Messages.Location = new System.Drawing.Point(37, 23);
            this.textBox_Messages.Multiline = true;
            this.textBox_Messages.Name = "textBox_Messages";
            this.textBox_Messages.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox_Messages.Size = new System.Drawing.Size(581, 202);
            this.textBox_Messages.TabIndex = 3;
            this.textBox_Messages.WordWrap = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 294);
            this.Controls.Add(this.textBox_Messages);
            this.Controls.Add(this.txtInputTimer);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "DataRobot";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtInputTimer_TextChanged(object sender, EventArgs e)
        {
        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox txtInputTimer;
        private System.Windows.Forms.TextBox textBox_Messages;
    }
}

