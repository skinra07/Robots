﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimulatedRobot;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.IO;

namespace DataRobot
{
    enum ScoreRank
    {
        NONE,
        HIGH,
        LOW,
        DISCARDED
    };

    public class RobotData
    {
        public byte commondId;
        public uint totalCount;
        public uint highCount;
        public double highSum;
        public uint lowCount;
        public double lowSum;
        public uint discardedCount;

        public RobotData(byte Id)
        {
            commondId = Id;
            totalCount = 0;
            highCount = 0;
            highSum = 0.0;
            lowCount = 0;
            lowSum = 0.0;
            discardedCount = 0;
        }

        public void IncrementTotalCount()
        {
            totalCount += 1;
        }

        public void IncrementHighCount()
        {
            highCount += 1;
        }

        public void IncrementLowCount()
        {
            lowCount += 1;
        }
        public void IncrementDiscardedCount()
        {
            discardedCount += 1;
        }
    }

    public class DisplayRobot : Robot
    {
        private ulong totalRecordProcess = 0;
        private DateTime startRun;
        private DateTime stopRun;

        private ConcurrentDictionary<string, RobotData> robotDataDict = null;

        public DisplayRobot()
        {
            robotDataDict = new ConcurrentDictionary<string, RobotData>();
        }

        ~DisplayRobot()
        {
            Dispose(false);
        }

        public void Dispose( bool disposing )
        {
            if ( disposing )
            {
                if (robotDataDict != null)
                {
                    robotDataDict.Clear();
                    robotDataDict = null;
                }

                this.Dispose();
            }
        }

        public override void Dispose()
        {
            if (robotDataDict != null)
            {
                robotDataDict.Clear();
                robotDataDict = null;
            }

            base.Dispose();
        }

        public void SubscribeEvent()
        {
            MessageReceived += ProcessMessage;
        }

        public void StartRunning()
        {
            SubscribeEvent();
            startRun = Start();
        }

        public void StopRunning()
        {
            stopRun = Stop();
        }

        private void ProcessMessage(object sender, byte[] rdata)
        {
            string cdata = String.Join(",", rdata);

            byte data_size = (byte)rdata[1];

            byte id_score_info = (byte)rdata[2];

            // Get ID and Score from CommandId
            uint id = ((uint)id_score_info >> 5) & 7;
            uint score = ((uint)id_score_info >> 0) & 0xF;
            
            // This create data_packet that only create data
            byte[] data_packet = new byte[data_size];
            Array.Copy((Array)rdata, 3, (Array)data_packet, 0, data_size);

            if ( id == 1)
            {
                short value = BitConverter.ToInt16(data_packet, 0);
                ProcessMessageID_1(score, value);
            }
            else if (id == 2)
            {
                double value1 = BitConverter.ToDouble(data_packet, 0);
                int value2 = BitConverter.ToInt32(data_packet, 8);
                double value3 = BitConverter.ToDouble(data_packet, 12);

                double final_value = (value1 + value3) + value2;

                ProcessMessageID_2(score, final_value);
            }
            else if (id == 3)
            {
                ProcessMessageID_3(score);
            }

            ++totalRecordProcess;
        }

        private void ProcessMessageID_1(uint score, short data)
        {
            RobotData dataValue = null;

            bool isExist = robotDataDict.TryGetValue("1", out dataValue);
            if (! isExist)
            {
                dataValue = new RobotData((byte)1);
            }

            double dbl_data = Convert.ToDouble(data);

            ScoreRank rank = EvaluateScore(score);
            
            if ( rank == ScoreRank.HIGH )
            {
                dataValue.IncrementHighCount();
                dataValue.highSum += dbl_data;
            }
            else if ( rank == ScoreRank.LOW)
            {
                dataValue.IncrementLowCount();
                dataValue.lowSum += dbl_data;
            }
            else if ( rank == ScoreRank.DISCARDED)
            {
                dataValue.IncrementDiscardedCount();
            }

            // Total Count
            dataValue.IncrementTotalCount();

            if (!isExist)
            {
                robotDataDict.TryAdd("1", dataValue);
            }
        }

        private void ProcessMessageID_2(uint score, double data)
        {
            RobotData dataValue = null;

            bool isExist = robotDataDict.TryGetValue("2", out dataValue);
            if (!isExist)
            {
                dataValue = new RobotData((byte)2);
            }

            ScoreRank rank = EvaluateScore(score);

            if (rank == ScoreRank.HIGH)
            {
                dataValue.IncrementHighCount();
                dataValue.highSum += data;
            }
            else if (rank == ScoreRank.LOW)
            {
                dataValue.IncrementLowCount();
                //fwriter.WriteLine("Before addition(LS): " + dataValue.lowSum);
                dataValue.lowSum += data;
            }
            else if (rank == ScoreRank.DISCARDED)
            {
                dataValue.IncrementDiscardedCount();
            }
            

            // Total Count
            dataValue.IncrementTotalCount();

            if (!isExist)
            {
                robotDataDict.TryAdd("2", dataValue);
            }
        }

        private void ProcessMessageID_3(uint score)
        {
            RobotData dataValue = null;

            bool isExist = robotDataDict.TryGetValue("3", out dataValue);
            if (!isExist)
            {
                dataValue = new RobotData((byte)3);
            }

            ScoreRank rank = EvaluateScore(score);

            if (rank == ScoreRank.HIGH)
            {
                dataValue.IncrementHighCount();
            }
            else if (rank == ScoreRank.LOW)
            {
                dataValue.IncrementLowCount();
            }
            else if (rank == ScoreRank.DISCARDED)
            {
                dataValue.IncrementDiscardedCount();
            }

            // Total Count
            dataValue.IncrementTotalCount();

            if (!isExist)
            {
                robotDataDict.TryAdd("3", dataValue);
            }
        }

        private ScoreRank EvaluateScore(uint score)
        {
            if (score >= 6 && score <= 9)
            {
                return ScoreRank.HIGH;
            }
            else if (score >= 3 && score <= 5)
            {
                return ScoreRank.LOW;
            }
            else if (score < 3)
            {
                return ScoreRank.DISCARDED;
            }
            return ScoreRank.NONE;
        }

        public string CreateDisplayData()
        {
            StringBuilder displayData = new StringBuilder();
    
            foreach (var item in robotDataDict )
            {
                RobotData rdata = item.Value;

                displayData.Append("[CMD]=").Append(item.Key).Append(" <=> ").Append("[TC]=").Append(rdata.totalCount).Append(" <=> ").Append("[HC]=").Append(rdata.highCount).Append(" <=> ");
                displayData.Append("[HS]=").Append(rdata.highSum).Append(" <=> ");
                displayData.Append("[LC]=").Append(rdata.lowCount).Append(" <=> ");
                displayData.Append("[LS]=").Append(rdata.lowSum).Append(" <=> ");
                displayData.Append("[DC]=").Append(rdata.discardedCount).Append("\r\n"); 
            }

            displayData.Append("\r\n");
            displayData.Append("Total Record Processed: ").Append(totalRecordProcess);
            
            return displayData.ToString();
           
        }

        public void CreateCSVFile()
        {
            string date_pattern = "yyyyMMddhhmmss";
            string startTime = startRun.ToString(date_pattern);
            string endTime = stopRun.ToString(date_pattern);

            string file_name = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + Path.DirectorySeparatorChar +  startTime + "-" + endTime + ".csv";

            using (StreamWriter sw = new StreamWriter(file_name))
            {
                sw.WriteLine("Command, Total Count, High Count, High Sum, Low Count, Low Sum, Discarded Count");
                StringBuilder rowContent = new StringBuilder();

                foreach (var row in robotDataDict)
                {
                    rowContent.Clear();
                    RobotData rdata = row.Value;

                    rowContent.Append(row.Key).Append(",").Append(rdata.totalCount).Append(",").Append(rdata.highCount).Append(",");
                    rowContent.Append(rdata.highSum).Append(",").Append(rdata.lowCount).Append(",").Append(rdata.lowSum).Append(",").Append(rdata.discardedCount);
                 
                    sw.WriteLine(rowContent.ToString());
                }
            }
        }
    }
}
